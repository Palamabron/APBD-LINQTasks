﻿using APBD4.Models;
using APBD4.Services;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace APBD4.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnimalsController : ControllerBase
    {
        
        private readonly IDbService _dbService;
        public AnimalsController(IDbService dbService)
        {
            _dbService = dbService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAnimals()
        {
            //DbService db = new(); złe podejście
            IList<Animal> result = await _dbService.GetAnimalAsync();

            return Ok(result);
        }

        [HttpGet("{name}")]
        public async Task<Animal> GetAnimal(string name)
        {
            return await _dbService.GetAnimalByNameAsync(name);
        }
        
        //[HttpDelete]

    }
}
