﻿using APBD4.Models;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace APBD4.Services
{
    public class DbService : IDbService
    {
        private const string ConnString = "Data Source=db-mssql;Initial Catalog=2019SBD;Integrated Security=True;";

        public async Task<IList<Animal>> GetAnimalAsync()
        {
            List<Animal> result = new();

            string sql = "SELECT * FROM Animal";

            await using SqlConnection connection = new(ConnString);
            await using SqlCommand comm = new(sql, connection);

            await connection.OpenAsync();

            await using SqlDataReader dr = await comm.ExecuteReaderAsync();

            //if(!dr.HasRows) //logika gdy nic nie sprowadzono z bazy
            //{

            //}

            while (await dr.ReadAsync())
            {
                result.Add(new Animal
                {
                    IdAnimal = int.Parse(dr["IdAnimal"].ToString()),
                    Name = dr["Name"].ToString(),
                    Description = dr["Description"].ToString(),
                    Category = dr["Category"].ToString(),
                    Area = dr["Area"].ToString()
                });
            }


            return result;
        }
        //zrobic get zwierzak
        //delete lub put zwierzaka
        public async Task<Animal> GetAnimalByNameAsync(string name)
        {
            string sql = "SELECT * FROM Animal WHERE Name = @name";

            await using SqlConnection connection = new(ConnString);
            await using SqlCommand comm = new(sql, connection);

            comm.Parameters.AddWithValue("name", name);
            await using SqlDataReader dr = await comm.ExecuteReaderAsync();

            await dr.ReadAsync();


            return new Animal
            {
                IdAnimal = int.Parse(dr["IdAnimal"].ToString()),
                Name = dr["Name"].ToString(),
                Description = dr["Description"].ToString(),
                Category = dr["Category"].ToString(),
                Area = dr["Area"].ToString()
            };
        }

        public async void AddAnimalAsync(Animal animal)
        {
            string sql = "INSERT INTO Animals(IdAnimal, Name, Description, Category, Area) VALUES" + $"(@id, @name, @description, @category, @area)";

            await using SqlConnection connection = new(ConnString);
            await using SqlCommand com = new SqlCommand(sql, connection);

            com.Parameters.AddWithValue("id", animal.IdAnimal);
            com.Parameters.AddWithValue("name", animal.Name);
            com.Parameters.AddWithValue("description", animal.Description);
            com.Parameters.AddWithValue("category", animal.Category);
            com.Parameters.AddWithValue("area", animal.Area);

            await connection.OpenAsync();

            com.ExecuteNonQuery();

            await connection.CloseAsync();
        }
        public async void UpdateAnimalAsync(int idAnimal, string label, string value)
        {
            string sql = "UPDATE Animal SET @label = @value WHERE IdAnimal = @id";

            await using SqlConnection connection = new(ConnString);
            await using SqlCommand com = new SqlCommand(sql, connection);

            com.Parameters.AddWithValue("id", idAnimal);
            com.Parameters.AddWithValue("label", label);
            com.Parameters.AddWithValue("value", value);

            await connection.OpenAsync();

            com.ExecuteNonQuery();

            await connection.CloseAsync();
        }

        public async void DeleteAnimalAsync(int idAnimal)
        {
            string sql = "DELETE FROM Animals WHERE idAnimal = " + $"@id";

            await using SqlConnection connection = new(ConnString);
            await using SqlCommand com = new SqlCommand(sql, connection);

            com.Parameters.AddWithValue("id", idAnimal);

            await connection.OpenAsync();

            com.ExecuteNonQuery();

            await connection.CloseAsync();
        }
    }
}
